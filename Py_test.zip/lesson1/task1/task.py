print(Input)
print(Input)
